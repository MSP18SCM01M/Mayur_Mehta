


public class Accessory implements java.io.Serializable{
	 String name;
	 double price;
	 String image;
	 String retailer;
	 String condition;
	 int discount;
	 double rebate;
	
	public Accessory(String name, double price, String image, String retailer,String condition,int discount,double rebate){
		this.name=name;
		this.price=price;
		this.image=image;
		this.condition=condition;
		this.discount=discount;
		this.retailer=retailer;
		this.rebate=rebate;
	}
	
	
	public Accessory() {
		
	}
	


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getRetailer() {
		return retailer;
	}

	public void setRetailer(String retailer) {
		this.retailer = retailer;
	}

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(int discount) {
		this.discount = discount;
	}
	public double getrebate() {
		return rebate;
	}
	
	public void setrebate(double rebate) {
		this.rebate = rebate;
	}
	

}
