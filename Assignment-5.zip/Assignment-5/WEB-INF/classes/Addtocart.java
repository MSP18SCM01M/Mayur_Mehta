import java.io.*; 
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;



public class Addtocart extends HttpServlet {
  public void doGet(HttpServletRequest request,
                    HttpServletResponse response)
      throws ServletException, IOException {
      response.setContentType("text/html;charset=UTF-8");
      		
	String prod=request.getParameter("button");
    String previouspage = request.getParameter("pagename");
    System.out.println(previouspage);
	  	

    for(Product p: SaxParser4SmartPortablesXMLDataStore.products)
    {
    	if(p.toString().equals(prod))
    	{
    		Cart.cartlist.add(p);
    	}
    }
    for(Accessory a: SaxParser4SmartPortablesXMLDataStore.accessories)
    {
    	if(a.toString().equals(prod))
    	{
    		Cart.cartlist.add(a);
    	}
    }
    
    if(previouspage.equals("viewcart"))
    {
    	response.sendRedirect("Viewcart");
    }
    else
    {
    	response.sendRedirect("ProductServlet?param1="+previouspage);
    }
		
		
	
	
}
}