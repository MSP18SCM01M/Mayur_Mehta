import java.io.*; 
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;



public class Deleteproduct extends HttpServlet {
  public void doGet(HttpServletRequest request,
                    HttpServletResponse response)
      throws ServletException, IOException {
		  
	response.setContentType("text/html;charset=UTF-8");
    PrintWriter out = response.getWriter();
    String productname=request.getParameter("productname");
        
    MySqlDataStoreUtilities.deleteProduct(productname);
   // response.sendRedirect("Saveprodmsg");
   out.println("<h3>Product has been deleted successfully!</h3>");
   out.println("<a href='Home'><h3>Go back to Home !</h3></td></tr>");
	
	  }
}