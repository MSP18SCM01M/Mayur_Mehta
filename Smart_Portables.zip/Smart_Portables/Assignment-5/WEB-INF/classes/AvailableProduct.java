

import java.util.*;

public class AvailableProduct implements java.io.Serializable{
	 String productname;
	 int price;
	 int quantity;
	 
	 //ArrayList<Accessory> accessories = new ArrayList<Accessory>();
	
	public AvailableProduct(String productname, int price, int quantity)//ArrayList<Accessory> accessories
	{
		this.productname=productname;
		this.price=price;
		this.quantity = quantity;
		//this.setAccessories(accessories);
	}
	
	public AvailableProduct(){
		
	}
	
	public String getProductname(){
		return productname;
	}
	
	public void setProductname(String productname){
		this.productname=productname;
	}
	
	
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
	
	/*public void setAccessories(ArrayList<Accessory> accessories) {
		this.accessories = accessories;
	}

	public ArrayList<Accessory> getAccessories() {
		return accessories;
	}*/

	
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}

