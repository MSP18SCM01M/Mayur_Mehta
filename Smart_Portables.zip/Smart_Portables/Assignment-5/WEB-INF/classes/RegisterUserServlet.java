import java.io.*;
import javax.servlet.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.util.*;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.*;



public class RegisterUserServlet extends HttpServlet{
	
  public static HashMap<String,SmartPortableUser> hm_user = new HashMap<String,SmartPortableUser>();
  public void doGet(HttpServletRequest request,
                    HttpServletResponse response)
      throws ServletException, IOException {
		  
	response.setContentType("text/html;charset=UTF-8");
    PrintWriter out = response.getWriter();
    
	HttpSession session = request.getSession();

	
    
   String category = request.getParameter("category");
    String fname = request.getParameter("firstname");
    String lname = request.getParameter("lastname");
    String uid = request.getParameter("uid");
    String email = request.getParameter("email");
    String password = request.getParameter("password");
    
   // SmartPortableUser newuser = new SmartPortableUser(fname,lname,uid,emailid,password,type);
    //hm_user.put(uid, newuser);
    
   MySqlDataStoreUtilities.insertUser(fname,lname,email,uid,password,category);   	
  
    out.println("<html>");
    out.println("<h3>You are successfully registered as a "+category+" !!</h3>");
    out.println("</html>");
	out.println("<a href='Login'>Click Here to Login");
	}
  
    //out.println("<html>");
   // out.println("<h3>Successfully Registered as a "+type+" !!</h3>");
    //out.println("</html>");
	   //out.println("<a href='Login'>Click Here to Login >");
    //response.sendRedirect("Home");

    
  }
  
  /* static void  writeUserDataStore(){

	    try{
	    File userDataStore=new File("C:/data_from_forms/UserDataStore");
	    FileOutputStream fos=new FileOutputStream(userDataStore);
	    ObjectOutputStream oos=new ObjectOutputStream(fos);

		
	        oos.writeObject(hm_user);
	        oos.flush();
	        oos.close();
	        fos.close();
		
	    }catch(Exception e){
			
		}

	}
  
  static void readUserDataStore() {

	   
	    try{
	        File userDataStore=new File("C:/data_from_forms/UserDataStore");
	        FileInputStream fis=new FileInputStream(userDataStore);
	        ObjectInputStream ois=new ObjectInputStream(fis);

	        HashMap<String,SmartPortableUser> mapInFile=(HashMap<String,SmartPortableUser>)ois.readObject();
	        ois.close();
	        fis.close();
	        
	    }catch(Exception e){
	    	
	    }

	} */
  
