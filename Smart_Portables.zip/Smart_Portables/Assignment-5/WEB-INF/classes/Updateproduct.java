import java.io.*; 
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;



public class Updateproduct extends HttpServlet {
  public void doGet(HttpServletRequest request,
                    HttpServletResponse response)
      throws ServletException, IOException {
		  
	response.setContentType("text/html;charset=UTF-8");
    PrintWriter out = response.getWriter();
    String productname=request.getParameter("productname");
    int price = Integer.parseInt(request.getParameter("price"));
    String retailer=request.getParameter("retailer");
  //  String manufacturer=request.getParameter("manufacturer");
    String cond=request.getParameter("cond");
    int discount=Integer.parseInt(request.getParameter("discount"));
    String prodtype=request.getParameter("prodtype");
    int rebate=Integer.parseInt(request.getParameter("rebate"));
	
    MySqlDataStoreUtilities.addProduct(productname,  price, retailer, cond, discount, prodtype, rebate);
   // response.sendRedirect("Saveprodmsg");
   out.println("<h3>Product has been updated successfully!</h3>");
   out.println("<a href='Home'><h3>Go back to Home !</h3></td></tr>");
	
	  }
}