import java.io.*; 
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.*;


public class ProductServlet extends HttpServlet {
  public void doGet(HttpServletRequest request,
                    HttpServletResponse response)
      throws ServletException, IOException {
		  
	response.setContentType("text/html;charset=UTF-8");
    PrintWriter out = response.getWriter();
	
	
    out.println("<html>");
		out.println("<head>");
			out.println("<meta http-equiv='Content-Type' content='text/html; charset=utf-8' content='no-cache'/>");
			out.println("<title>Smart Portables</title>");
			out.println("<link rel='shortcut icon' href='images/icon.jpg'/>");
			out.println("<link rel='stylesheet' href='styles.css' type='text/css' />");
			
			out.println("<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'> ");
			out.println("<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>");
			out.println("<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>");
			out.println("<script src='script.js'></script>");
			
		out.println("</head>");
		out.println("<body>");
			out.println("<div id='container'>");
			out.println("<header>");
			out.println("<h1><a href='/'>Smart <span> Portables</span></a></h1>");
			out.println("</header>");
			out.println("<nav>");
			out.println("<ul>");
			out.println("<li  class='start selected'><a id='Home' href='Home'>Home</a></li>");
			out.println("<li  class=''><a href='ProductServlet?param1=Watches'>Watches</a></li>");
			out.println("<li  class=''><a href='ProductServlet?param1=Mobiles'>Mobiles</a></li>");
			out.println("<li  class=''><a href='ProductServlet?param1=Laptops'>Laptops</a></li>");			
			out.println("<li  class=''><a href='ProductServlet?param1=Speakers'>Speakers</a></li>");
			out.println("<li  class=''><a href='ProductServlet?param1=Earphones'>Earphones</a></li>");
			out.println("<li  class=''><a href='ProductServlet?param1=ExternalStorage'>ExternalStorage</a></li>");
			
				HttpSession session = request.getSession();
	String fname=(String)session.getAttribute("fname");
	
	if (fname == null)
	{
	out.println("<li class=''><a href='Register'>Register</a></li>");
	out.println("<li class='' ><a href='Login'>Login</a></li>");
	}
	else
	{
		out.println("<li class=''><a href='#'>Hello  "+fname+"</a></li>");
		out.println("<li class='' ><a href='Logout'>Logout</a></li>");
	}

	
	out.println("<li class=''><a href='Vieworder'>View Orders</a></li>");
	
	out.println("<div align='right'>");
	out.println("<form action='Viewcart'>");
	out.println("<button type='submit' style='background-color:transparent'><img src='images/Cart.png' width = '60px' height = '63px'></button>");
	out.println("</form>");
	out.println("</ul>");
	out.println("</nav>");
	out.println("</div>");
			
	
	out.println("<div id='body'>");
	out.println("<section id='content'>");
	//MySqlDataStoreUtilities.insertOrderDetails(HashMap<String, Console> orderDetails);//edited here
	
	SmartPortablesSerializedDataStore obj1=(SmartPortablesSerializedDataStore) request.getAttribute("obj1");
	String product_type=request.getParameter("param1");
	//out.println("<h5>"+s1+"</h5>");
	//obj1.hm_accessories.get("acc1").getPrice();
	//System.out.println(obj.hm_smartwatches);
	//System.out.println(obj.hm_smartwatches.get("SmartWatch1"));
	//out.println("<h5>"+obj1.hm_accessories.get("acc1").getName()+"</h5>");
	HashMap<String,Product> map = new HashMap<String,Product>();
	HashMap<String, Accessory> map1 = new HashMap<String,Accessory>();
	
	if(product_type.equalsIgnoreCase("Watches")){
		map=obj1.Hm_Watches;
		out.println("<h1> WATCHES </h1>");
	}
	else if(product_type.equalsIgnoreCase("Mobiles")){
		map=obj1.Hm_Mobiles;
		out.println("<h1> MOBILES </h1>");
	}
	else if(product_type.equalsIgnoreCase("Laptops")){
		map=obj1.Hm_Laptops;
		out.println("<h1> LAPTOPS </h1>");
	}
	else if(product_type.equalsIgnoreCase("Speakers")){
		map=obj1.Hm_Speakers;
		out.println("<h1> SPEAKERS </h1>");
	}
	else if(product_type.equalsIgnoreCase("Earphones")){
		map=obj1.Hm_Earphones;
		out.println("<h1> EARPHONES </h1>");
	}
	else if(product_type.equalsIgnoreCase("ExternalStorage")){
		map=obj1.Hm_ExternalStorage;
		//System.out.println(map.size());
		out.println("<h1> EXTERNAL STORAGES </h1>");
	}
	else if(product_type.equalsIgnoreCase("Accessories")){
		map1=obj1.Hm_accessories;
		out.println("<h1> ACCESSORIES </h1>");
	}
	
	
	//out.println("First here");
	
	for(String key:map.keySet())
	{	
		out.println("<div id='container'>");
		out.println("<h5> Name: "+map.get(key).getName()+"</h5>");
		out.println("<img src =images/"+map.get(key).getImage()+" width='25%' height='25%'>");
		out.println("<h5> Price: "+map.get(key).getPrice()+"</h5>");
		out.println("<h5> Retailer: "+map.get(key).getRetailer()+"</h5>");
		out.println("<h3> Condition: "+map.get(key).getCondition()+"</h3>");
		out.println("<h3> Discount: "+map.get(key).getDiscount()+"</h3>");
		out.println("<form id='addtocart' method='get' action='Addtocart'>");
		//out.println("<input class = 'submit-button' type = 'submit' value = 'Add to Cart' style='background-color:transparent'>");
		out.println("<input type='hidden' name='pagename' value="+product_type+"></input>");
		out.println("<button type='submit' name='button' value="+map.get(key)+">Add to cart</button>");
		out.println("<br>");
		out.println("<br>");
		out.println("</form>");
		
		//Write Reviews	
	out.println("<form id = 'prodwritereview' method = 'get' action = 'WriteReview'>");
	out.println("<input type='hidden' name='product_type' value="+product_type+"></input>");
	//out.println("<input type='hidden' name='product_name' value="+map.get(key).getName()+"></input>");
	out.println("<button type='submit' name='button' value="+map.get(key).getName()+">Write Review</button>");	  
	out.println("</form>");
	out.println("<br>");
	
	//View Reviews	
	out.println("<form id = 'prodviewreview' method = 'get' action = 'ViewReview'>");
	out.println("<input type='hidden' name='product_name' value="+map.get(key).getName()+"></input>");
	out.println("<button type='submit' name='button' value="+map.get(key).getName()+">View Review</button>");	  
	out.println("</form>");
		
	

		
		//out.println("<button onclick=AddToCart("+map.get(key)+")>Add to cart</button>");
		
	ArrayList<Accessory> acclist = map.get(key).getAccessories();
		if(acclist.size()!=0)
			out.println("<h2>Accessories</h2>");
		/*for(Accessory acc : acclist)
		{
			out.println("<h3> Name: "+acc.getName()+"</h3>");
			out.println("<img src =images/"+acc.getImage()+" width='20%' height='20%'>");
			out.println("<h5> Price: "+acc.getPrice()+"</h5>");
			out.println("<form id='prodaddtocart' action='ProductServlet'>");
			out.println("<input type='submit' value='Add to cart' style='background-color:transparent'></input>");
			out.println("</form>");
		}*/
		if(acclist.size()!=0){
		out.println("<div align='center'>");
		out.println("<div id='myCarousel' class='carousel slide' data-ride='carousel'>");
		 
			out.println("<ol class='carousel-indicators'>");
			out.println("<li data-target='#myCarousel' data-slide-to='0' class='active'></li>");
			out.println("<li data-target='#myCarousel' data-slide-to='1'></li>");
			out.println("<li data-target='#myCarousel' data-slide-to='2'></li>");
			out.println("</ol>");
			
		out.println("<div class='carousel-inner'>");
			
			out.println("<div class='item active'>");
			out.println("<img src =images/"+acclist.get(0).getImage()+" width='30%' height='30%'>");
			//out.println("<div class='carousel-caption'>");
			out.println("<h1>"+acclist.get(0).getName()+"</h1>");
			out.println("<h1>$ "+acclist.get(0).getPrice()+"</h1>");
          out.println("<button onclick=Addtocart("+map1.get(key)+")><h4>Add to cart</h4></button>");
          out.println("</div>");
			//out.println("</div>");
			
			
			for(int i=1;i<acclist.size();i++)
			{
				out.println("<div class='item'>");
				out.println("<img src =images/"+acclist.get(i).getImage()+" width='20%' height='20%'>");
				out.println("<h1>"+acclist.get(i).getName()+"</h1>");
				out.println("<h1>$ "+acclist.get(i).getPrice()+"</h1>");
				out.println("<button onclick=Addtocart("+map1.get(key)+")><h4>Add to cart</h4></button>");
				out.println("</div>");
			}
			
		out.println("</div>");	
		
		out.println("<a class='left carousel-control' href='#myCarousel' data-slide='prev'>");
		out.println("<span class='glyphicon glyphicon-chevron-left'></span>");
		out.println("<span class='sr-only'>Previous</span>");
		out.println("</a>");
		out.println("<a class='right carousel-control' href='#myCarousel' data-slide='next'>");
		out.println("<span class='glyphicon glyphicon-chevron-right'></span>");
		out.println("<span class='sr-only'>Next</span>");
		out.println("</a>");
		out.println("</div>");
		out.println("</div>");
		}
		
		
		out.println("</div>");
	}
	//accessorries maate
	for(String key:map1.keySet())
	{
		out.println("<div id='container'>");
		out.println("<h3> Name: "+map.get(key).getName()+"</h3>");
		out.println("<img src =images/"+map1.get(key).getImage()+" width='25%' height='25%'>");
		out.println("<h5> Price:$ "+map1.get(key).getPrice()+"</h5>");
		out.println("<h5> Retailer: "+map1.get(key).getRetailer()+"</h5>");
		out.println("<h5> Condition: "+map1.get(key).getCondition()+"</h5>");
		out.println("<h5> Discount:$ "+map1.get(key).getDiscount()+"</h5>");
		out.println("<form id='prodaddtocart' action='Addtocart'>");
		out.println("<input type='hidden' name='pagename' value="+product_type+"></input>");
		out.println("<button type='submit' name='button' value="+map1.get(key)+">Add to cart</button>");
		out.println("</form>");
		out.println("</div>");
		
	}
	
	

	
	//out.println("out of loop");
	
	out.println("</section>");
	out.println("<aside class='sidebar'>");
	out.println("<ul>");	
	out.println("<li>");
	out.println("<h4>Products</h4>");
	out.println("<ul>");
	out.println("<li  class='start selected'><a id='Home' href='Home'>Home</a></li>");
	out.println("<li  class=''><a href='ProductServlet?param1=Watches'>Watches</a></li>");
	out.println("<li  class=''><a href='ProductServlet?param1=Mobiles'>Mobiles</a></li>");
	out.println("<li  class=''><a href='ProductServlet?param1=Laptops'>Laptops</a></li>");			
	out.println("<li  class=''><a href='ProductServlet?param1=Speakers'>Speakers</a></li>");
	out.println("<li  class=''><a href='ProductServlet?param1=Earphones'>Earphones</a></li>");
	out.println("<li  class=''><a href='ProductServlet?param1=ExternalStorage'>ExternalStorage</a></li>");
	out.println("</ul>");
	out.println("</li>");	
	out.println("<li>");
	out.println("<h4>About us</h4>");
	out.println("<ul>");
	out.println("<li class='text'>");
	out.println("<p style='margin: 0;'>This is a sample website created to demonstrate a standard enterprise web page.</p>");
	out.println(" </li>");
	out.println("</ul>");
	out.println("</li>");	
	out.println("<li>");
	out.println("<h4>Search site</h4>");
	out.println("<ul>");
	out.println("<li class='text'>");
	out.println("<form method='get' class='searchform' action='#'>");
	out.println("<p>");
	out.println("<input type='text' size='25' value='' name='s' class='s' />");
	out.println("</p>");	
	out.println("</form></li></ul></li>");	     	
	out.println("<li>");	
	out.println("<h4>Helpful Links</h4>");	
	out.println("<ul>");	
	out.println("<li><a href='http://www.w3schools.com/html/default.asp' title='premium templates'>Learn HTML here</a></li>");	
	out.println("<li><a href='http://www.w3schools.com/css/default.asp' title='web hosting'>Learn CSS here</a></li>");	
	out.println("</ul></li></ul></aside>");	
	out.println("<div class='clear'></div>");
	out.println("</div>");	
	out.println("<footer>");	
	out.println("<div class='footer-content'>");	
	out.println("<div class='clear'></div>");	
	out.println("</div>");	
	out.println("<div class='footer-bottom'>");	
	out.println("<p>Smart Portables - Enterprise Web Application </p>");	
	out.println("</div>");	
	out.println("</footer>");	
	out.println("</div>");	
			
	out.println("</body>");
	out.println("</html>");
			
	 }
	 
	 
	 public void doPost(HttpServletRequest request,
                    HttpServletResponse response)
      throws ServletException, IOException {
		  
   
	response.setContentType("text/html;charset=UTF-8");
    PrintWriter out = response.getWriter();
	
	
    out.println("<html>");
		out.println("<head>");
			out.println("<meta http-equiv='Content-Type' content='text/html; charset=utf-8' content='no-cache'/>");
			out.println("<title>Smart Portables</title>");
			out.println("<link rel='shortcut icon' href='images/icon.jpg'/>");
			out.println("<link rel='stylesheet' href='styles.css' type='text/css' />");
			
			out.println("<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'> ");
			out.println("<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>");
			out.println("<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>");
			out.println("<script src='script.js'></script>");
			
		out.println("</head>");
		out.println("<body>");
			out.println("<div id='container'>");
			out.println("<header>");
			out.println("<h1><a href='/'>Smart <span> Portables</span></a></h1>");
			out.println("</header>");
			out.println("<nav>");
			out.println("<ul>");
			out.println("<li  class='start selected'><a id='Home' href='Home'>Home</a></li>");
			out.println("<li  class=''><a href='ProductServlet?param1=Watches'>Watches</a></li>");
			out.println("<li  class=''><a href='ProductServlet?param1=Mobiles'>Mobiles</a></li>");
			out.println("<li  class=''><a href='ProductServlet?param1=Laptops'>Laptops</a></li>");			
			out.println("<li  class=''><a href='ProductServlet?param1=Speakers'>Speakers</a></li>");
			out.println("<li  class=''><a href='ProductServlet?param1=Earphones'>Earphones</a></li>");
			out.println("<li  class=''><a href='ProductServlet?param1=ExternalStorage'>ExternalStorage</a></li>");
			
				HttpSession session = request.getSession();
	String fname=(String)session.getAttribute("fname");
	
	if (fname == null)
	{
	out.println("<li class=''><a href='Register'>Register</a></li>");
	out.println("<li class='' ><a href='Login'>Login</a></li>");
	}
	else
	{
		out.println("<li class=''><a href='#'>Hello  "+fname+"</a></li>");
		out.println("<li class='' ><a href='Logout'>Logout</a></li>");
	}

	
	out.println("<li class=''><a href='Vieworders'>View Orders</a></li>");
	
	out.println("<div align='right'>");
	out.println("<form action='Viewcart'>");
	out.println("<button type='submit' style='background-color:transparent'><img src='images/Cart.png' width = '60px' height = '63px'></button>");
	out.println("</form>");
	out.println("</ul>");
	out.println("</nav>");
	out.println("</div>");
			
	
	out.println("<div id='body'>");
	out.println("<section id='content'>");
	//MySqlDataStoreUtilities.insertOrderDetails(HashMap<String, Console> orderDetails);//edited here
	
	SmartPortablesSerializedDataStore obj1=(SmartPortablesSerializedDataStore) request.getAttribute("obj1");
	String product_type=request.getParameter("param1");
	//out.println("<h5>"+s1+"</h5>");
	//obj1.hm_accessories.get("acc1").getPrice();
	//System.out.println(obj.hm_smartwatches);
	//System.out.println(obj.hm_smartwatches.get("SmartWatch1"));
	//out.println("<h5>"+obj1.hm_accessories.get("acc1").getName()+"</h5>");
	HashMap<String,Product> map = new HashMap<String,Product>();
	HashMap<String, Accessory> map1 = new HashMap<String,Accessory>();
	if(product_type.equalsIgnoreCase("Watches")){
		map=obj1.Hm_Watches;
		out.println("<h1> WATCHES </h1>");
	}
	else if(product_type.equalsIgnoreCase("Mobiles")){
		map=obj1.Hm_Mobiles;
		out.println("<h1> MOBILES </h1>");
	}
	else if(product_type.equalsIgnoreCase("Laptops")){
		map=obj1.Hm_Laptops;
		out.println("<h1> LAPTOPS </h1>");
	}
	else if(product_type.equalsIgnoreCase("Speakers")){
		map=obj1.Hm_Speakers;
		out.println("<h1> SPEAKERS </h1>");
	}
	else if(product_type.equalsIgnoreCase("Earphones")){
		map=obj1.Hm_Earphones;
		out.println("<h1> EARPHONES </h1>");
	}
	else if(product_type.equalsIgnoreCase("ExternalStorage")){
		map=obj1.Hm_ExternalStorage;
		//System.out.println(map.size());
		out.println("<h1> EXTERNAL STORAGES </h1>");
	}
	else if(product_type.equalsIgnoreCase("Accessories")){
		map1=obj1.Hm_accessories;
		out.println("<h1> ACCESSORIES </h1>");
	}
	
	
	//out.println("First here");
	
	for(String key:map.keySet())
	{	
		out.println("<div id='container'>");
		out.println("<h5> Name: "+map.get(key).getName()+"</h5>");
		out.println("<img src =images/"+map.get(key).getImage()+" width='25%' height='25%'>");
		out.println("<h5> Price: "+map.get(key).getPrice()+"</h5>");
		out.println("<h5> Retailer: "+map.get(key).getRetailer()+"</h5>");
		out.println("<h3> Condition: "+map.get(key).getCondition()+"</h3>");
		out.println("<h3> Discount: "+map.get(key).getDiscount()+"</h3>");
		out.println("<form id='addtocart' method='get' action='Addtocart'>");
		//out.println("<input class = 'submit-button' type = 'submit' value = 'Add to Cart' style='background-color:transparent'>");
		out.println("<input type='hidden' name='pagename' value="+product_type+"></input>");
		out.println("<button type='submit' name='button' value="+map.get(key)+">Add to cart</button>");
		out.println("<br>");
		out.println("<br>");
		out.println("</form>");
		
		//Write Reviews	
	out.println("<form id = 'prodwritereview' method = 'get' action = 'WriteReview'>");
	out.println("<input type='hidden' name='product_type' value="+product_type+"></input>");
	//out.println("<input type='hidden' name='product_name' value="+map.get(key).getName()+"></input>");
	out.println("<button type='submit' name='button' value="+map.get(key).getName()+">Write Review</button>");	  
	out.println("</form>");
	out.println("<br>");
	
	//View Reviews	
	out.println("<form id = 'prodviewreview' method = 'get' action = 'ViewReview'>");
	out.println("<input type='hidden' name='product_name' value="+map.get(key).getName()+"></input>");
	out.println("<button type='submit' name='button' value="+map.get(key).getName()+">View Review</button>");	  
	out.println("</form>");
		
	

		
		//out.println("<button onclick=AddToCart("+map.get(key)+")>Add to cart</button>");
		
	ArrayList<Accessory> acclist = map.get(key).getAccessories();
		if(acclist.size()!=0)
			out.println("<h2>Accessories</h2>");
		/*for(Accessory acc : acclist)
		{
			out.println("<h3> Name: "+acc.getName()+"</h3>");
			out.println("<img src =images/"+acc.getImage()+" width='20%' height='20%'>");
			out.println("<h5> Price: "+acc.getPrice()+"</h5>");
			out.println("<form id='prodaddtocart' action='ProductServlet'>");
			out.println("<input type='submit' value='Add to cart' style='background-color:transparent'></input>");
			out.println("</form>");
		}*/
		if(acclist.size()!=0){
		out.println("<div align='center'>");
		out.println("<div id='myCarousel' class='carousel slide' data-ride='carousel'>");
		 
			out.println("<ol class='carousel-indicators'>");
			out.println("<li data-target='#myCarousel' data-slide-to='0' class='active'></li>");
			out.println("<li data-target='#myCarousel' data-slide-to='1'></li>");
			out.println("<li data-target='#myCarousel' data-slide-to='2'></li>");
			out.println("</ol>");
			
		out.println("<div class='carousel-inner'>");
			
			out.println("<div class='item active'>");
			out.println("<img src =images/"+acclist.get(0).getImage()+" width='30%' height='30%'>");
			//out.println("<div class='carousel-caption'>");
			out.println("<h1>"+acclist.get(0).getName()+"</h1>");
			out.println("<h1>$ "+acclist.get(0).getPrice()+"</h1>");
          out.println("<button onclick=Addtocart("+map1.get(key)+")><h4>Add to cart</h4></button>");
          out.println("</div>");
			//out.println("</div>");
			
			
			for(int i=1;i<acclist.size();i++)
			{
				out.println("<div class='item'>");
				out.println("<img src =images/"+acclist.get(i).getImage()+" width='20%' height='20%'>");
				out.println("<h1>"+acclist.get(i).getName()+"</h1>");
				out.println("<h1>$ "+acclist.get(i).getPrice()+"</h1>");
				out.println("<button onclick=Addtocart("+map1.get(key)+")><h4>Add to cart</h4></button>");
				out.println("</div>");
			}
			
		out.println("</div>");	
		
		out.println("<a class='left carousel-control' href='#myCarousel' data-slide='prev'>");
		out.println("<span class='glyphicon glyphicon-chevron-left'></span>");
		out.println("<span class='sr-only'>Previous</span>");
		out.println("</a>");
		out.println("<a class='right carousel-control' href='#myCarousel' data-slide='next'>");
		out.println("<span class='glyphicon glyphicon-chevron-right'></span>");
		out.println("<span class='sr-only'>Next</span>");
		out.println("</a>");
		out.println("</div>");
		out.println("</div>");
		}
		
		
		out.println("</div>");
	}
	//accessorries maate
	for(String key:map1.keySet())
	{
		out.println("<div id='container'>");
		out.println("<h3> Name: "+map1.get(key).getName()+"</h3>");
		out.println("<img src =images/"+map1.get(key).getImage()+" width='25%' height='25%'>");
		out.println("<h5> Price:$ "+map1.get(key).getPrice()+"</h5>");
		out.println("<h5> Retailer: "+map1.get(key).getRetailer()+"</h5>");
		out.println("<h5> Condition: "+map1.get(key).getCondition()+"</h5>");
		out.println("<h5> Discount:$ "+map1.get(key).getDiscount()+"</h5>");
		out.println("<form id='prodaddtocart' action='Addtocart'>");
		out.println("<input type='hidden' name='pagename' value="+product_type+"></input>");
		out.println("<button type='submit' name='button' value="+map1.get(key)+">Add to cart</button>");
		out.println("</form>");
		out.println("</div>");
		
	}
	
	

	
	//out.println("out of loop");
	
	out.println("</section>");
	out.println("<aside class='sidebar'>");
	out.println("<ul>");	
	out.println("<li>");
	out.println("<h4>Products</h4>");
	out.println("<ul>");
	out.println("<li  class='start selected'><a id='Home' href='Home'>Home</a></li>");
	out.println("<li  class=''><a href='ProductServlet?param1=Watches'>Watches</a></li>");
	out.println("<li  class=''><a href='ProductServlet?param1=Mobiles'>Mobiles</a></li>");
	out.println("<li  class=''><a href='ProductServlet?param1=Laptops'>Laptops</a></li>");			
	out.println("<li  class=''><a href='ProductServlet?param1=Speakers'>Speakers</a></li>");
	out.println("<li  class=''><a href='ProductServlet?param1=Earphones'>Earphones</a></li>");
	out.println("<li  class=''><a href='ProductServlet?param1=ExternalStorage'>ExternalStorage</a></li>");
	out.println("</ul>");
	out.println("</li>");	
	out.println("<li>");
	out.println("<h4>About us</h4>");
	out.println("<ul>");
	out.println("<li class='text'>");
	out.println("<p style='margin: 0;'>This is a sample website created to demonstrate a standard enterprise web page.</p>");
	out.println(" </li>");
	out.println("</ul>");
	out.println("</li>");	
	out.println("<li>");
	out.println("<h4>Search site</h4>");
	out.println("<ul>");
	out.println("<li class='text'>");
	out.println("<form method='get' class='searchform' action='#'>");
	out.println("<p>");
	out.println("<input type='text' size='25' value='' name='s' class='s' />");
	out.println("</p>");	
	out.println("</form></li></ul></li>");	     	
	out.println("<li>");	
	out.println("<h4>Helpful Links</h4>");	
	out.println("<ul>");	
	out.println("<li><a href='http://www.w3schools.com/html/default.asp' title='premium templates'>Learn HTML here</a></li>");	
	out.println("<li><a href='http://www.w3schools.com/css/default.asp' title='web hosting'>Learn CSS here</a></li>");	
	out.println("</ul></li></ul></aside>");	
	out.println("<div class='clear'></div>");
	out.println("</div>");	
	out.println("<footer>");	
	out.println("<div class='footer-content'>");	
	out.println("<div class='clear'></div>");	
	out.println("</div>");	
	out.println("<div class='footer-bottom'>");	
	out.println("<p>Smart Portables - Enterprise Web Application </p>");	
	out.println("</div>");	
	out.println("</footer>");	
	out.println("</div>");	
			
	out.println("</body>");
	out.println("</html>");
			
				
	 }
}
